from django.contrib import admin
from newaccount.models import Person, Contact

# Register your models here.
admin.site.register(Person)
admin.site.register(Contact)