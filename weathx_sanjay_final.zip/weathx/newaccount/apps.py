from django.apps import AppConfig


class NewaccountConfig(AppConfig):
    name = 'newaccount'
