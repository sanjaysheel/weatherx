from django.contrib import admin
from .models import City 
# Register your models here.a

admin.site.register(City)