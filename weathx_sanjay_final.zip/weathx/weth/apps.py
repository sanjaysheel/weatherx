from django.apps import AppConfig


class WethConfig(AppConfig):
    name = 'weth'
